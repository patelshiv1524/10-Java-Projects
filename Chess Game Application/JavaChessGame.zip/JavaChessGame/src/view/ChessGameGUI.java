package view;

import controller.ChessController;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import model.ChessGame;
import model.Piece;
import model.Position;
import model.PieceColor;

import java.util.HashMap;
import java.util.Map;

public class ChessGameGUI extends Application {
    private ChessController controller;
    private final ChessSquareComponent[][] squares = new ChessSquareComponent[8][8];

    private final Map<Class<? extends Piece>, String> pieceUnicodeMap = new HashMap<>() {
        {
            put(model.Pawn.class, "\u265F");
            put(model.Rook.class, "\u265C");
            put(model.Knight.class, "\u265E");
            put(model.Bishop.class, "\u265D");
            put(model.Queen.class, "\u265B");
            put(model.King.class, "\u265A");
        }
    };

    @Override
    public void start(Stage primaryStage) {
        controller = new ChessController(this); // Initialize controller
        primaryStage.setTitle("Chess Game");

        GridPane boardGrid = new GridPane();
        initializeBoard(boardGrid);

        // Menu bar with Reset option
        MenuBar menuBar = new MenuBar();
        Menu gameMenu = new Menu("Game");
        MenuItem resetItem = new MenuItem("Reset");
        resetItem.setOnAction(e -> resetGame());
        gameMenu.getItems().add(resetItem);
        menuBar.getMenus().add(gameMenu);

        // Setting up the scene
        javafx.scene.layout.VBox root = new javafx.scene.layout.VBox();
        root.getChildren().addAll(menuBar, boardGrid);
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void initializeBoard(GridPane boardGrid) {
        for (int row = 0; row < squares.length; row++) {
            for (int col = 0; col < squares[row].length; col++) {
                ChessSquareComponent square = new ChessSquareComponent(row, col);
                final int finalRow = row;
                final int finalCol = col;
                square.setOnMouseClicked(e -> handleSquareClick(finalRow, finalCol)); // Handle click
                boardGrid.add(square, col, row);
                squares[row][col] = square;
            }
        }
        updateBoard(); // Initial display of pieces
    }

    private void handleSquareClick(int row, int col) {
        boolean moveResult = controller.handleSquareClick(row, col); // Delegate to controller
        clearHighlights();
        if (moveResult) {
            updateBoard(); // Refresh board
            checkGameState();
            checkGameOver();
        } else if (controller.getGame().isPieceSelected()) {
            highlightLegalMoves(new Position(row, col));
        }
    }

    public void updateBoard() {
        // Refresh the board based on the current state
        ChessGame game = controller.getGame();
        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                Piece piece = game.getBoard().getPiece(row, col);
                if (piece != null) {
                    String symbol = pieceUnicodeMap.get(piece.getClass());
                    javafx.scene.paint.Color color = (piece.getColor() == PieceColor.WHITE) ? javafx.scene.paint.Color.WHITE : javafx.scene.paint.Color.BLACK;
                    squares[row][col].setPieceSymbol(symbol, color);
                } else {
                    squares[row][col].clearPieceSymbol();
                }
            }
        }
    }

    private void checkGameState() {
        PieceColor currentPlayer = controller.getGame().getCurrentPlayerColor();
        if (controller.getGame().isInCheck(currentPlayer)) {
            showAlert(currentPlayer + " is in check!");
        }
    }

    private void highlightLegalMoves(Position position) {
        var legalMoves = controller.getGame().getLegalMovesForPieceAt(position);
        for (Position move : legalMoves) {
            squares[move.getRow()][move.getColumn()].setStyle("-fx-background-color: green;");
        }
    }

    private void clearHighlights() {
        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                squares[row][col].resetBackground(row, col);
            }
        }
    }

    private void resetGame() {
        controller.getGame().resetGame();
        updateBoard();
    }
    

    private void checkGameOver() {
        if (controller.getGame().isCheckmate(controller.getGame().getCurrentPlayerColor())) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Checkmate! Would you like to play again?");
            alert.showAndWait().ifPresent(response -> {
                if (response == javafx.scene.control.ButtonType.OK) {
                    resetGame();
                } else {
                    System.exit(0);
                }
            });
        }
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION, message);
        alert.showAndWait();
    }

    public ChessSquareComponent getSquare(int row, int col) {
        return squares[row][col];
    }

    public static void main(String[] args) {
        launch(args);
    }
}
