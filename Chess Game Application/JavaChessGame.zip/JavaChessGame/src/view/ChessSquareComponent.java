package view;

import javafx.scene.control.Button;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import model.Piece;
import model.PieceColor;

public class ChessSquareComponent extends Button {
    private int row;
    private int col;

    public ChessSquareComponent(int row, int col) {
        this.row = row;
        this.col = col;
        initButton();
    }

    /**
     * Initializes the button appearance, including size, font, and background color.
     */
    private void initButton() {
        setPrefSize(80, 80); // Adjust size for better visibility
        setFont(new Font("DejaVu Sans", 36)); // Set font for Unicode chess symbols
        resetBackground(row, col); // Set initial background color based on position
    }

    /**
     * Sets the Unicode symbol for a given chess piece, applying color based on piece color.
     * 
     * @param piece The piece to display on this square.
     */
    public void setPieceSymbol(Piece piece) {
        if (piece != null) {
            String symbol = getUnicodeSymbol(piece);
            this.setText(symbol);
            this.setTextFill(piece.getColor() == PieceColor.WHITE ? Color.WHITE : Color.BLACK);
        } else {
            clearPieceSymbol(); // Clear if no piece
        }
    }

    /**
     * Clears the piece symbol from the square.
     */
    public void clearPieceSymbol() {
        this.setText(""); // Remove text from the button
    }

    /**
     * Sets the Unicode symbol and color directly, used by the controller.
     * 
     * @param symbol The Unicode symbol to display.
     * @param color  The color of the symbol.
     */
    public void setPieceSymbol(String symbol, Color color) {
        this.setText(symbol);
        this.setTextFill(color);
    }

    /**
     * Returns the appropriate Unicode symbol for a piece based on its type and color.
     * 
     * @param piece The chess piece.
     * @return The Unicode symbol representing the piece.
     */
    private String getUnicodeSymbol(Piece piece) {
        if (piece.getColor() == PieceColor.WHITE) {
            switch (piece.getClass().getSimpleName()) {
                case "Pawn": return "\u2659";
                case "Rook": return "\u2656";
                case "Knight": return "\u2658";
                case "Bishop": return "\u2657";
                case "Queen": return "\u2655";
                case "King": return "\u2654";
            }
        } else {
            switch (piece.getClass().getSimpleName()) {
                case "Pawn": return "\u265F";
                case "Rook": return "\u265C";
                case "Knight": return "\u265E";
                case "Bishop": return "\u265D";
                case "Queen": return "\u265B";
                case "King": return "\u265A";
            }
        }
        return ""; // Fallback if no symbol found
    }

    /**
     * Resets the background color to create a traditional brown and cream checkered pattern.
     * 
     * @param row Row position of the square.
     * @param col Column position of the square.
     */
    public void resetBackground(int row, int col) {
        if ((row + col) % 2 == 0) {
            setStyle("-fx-background-color: #D2B48C;"); // Cream color
        } else {
            setStyle("-fx-background-color: #8B4513;"); // Brown color
        }
    }
}
