package com.example.restaurantguideapp.models;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "restaurants")
public class Restaurant {

    @PrimaryKey(autoGenerate = true)
    private int id; // Unique ID for each restaurant
    private String name; // Name of the restaurant
    private String address; // Address
    private String phone; // Contact number
    private String description; // Description
    private String tags; // Tags like "Vegan", "Italian"
    private float rating; // Rating (1-5 stars)
    private double latitude; // Latitude for location
    private double longitude; // Longitude for location

    // Getters and setters for each field
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getTags() { return tags; }
    public void setTags(String tags) { this.tags = tags; }
    public float getRating() { return rating; }
    public void setRating(float rating) { this.rating = rating; }
    public double getLatitude() { return latitude; }
    public void setLatitude(double latitude) { this.latitude = latitude; }
    public double getLongitude() { return longitude; }
    public void setLongitude(double longitude) { this.longitude = longitude; }
}
