package com.example.restaurantguideapp.activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.restaurantguideapp.R;

public class RestaurantDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant_detail);

        String name = getIntent().getStringExtra("name");
        String address = getIntent().getStringExtra("address");
        String phone = getIntent().getStringExtra("phone");
        String description = getIntent().getStringExtra("description");
        String tags = getIntent().getStringExtra("tags");
        double latitude = getIntent().getDoubleExtra("latitude", 0.0);
        double longitude = getIntent().getDoubleExtra("longitude", 0.0);

        TextView textName = findViewById(R.id.text_name);
        TextView textAddress = findViewById(R.id.text_address);
        TextView textPhone = findViewById(R.id.text_phone);
        TextView textDescription = findViewById(R.id.text_description);
        TextView textTags = findViewById(R.id.text_tags);

        textName.setText(name);
        textAddress.setText(address);
        textPhone.setText(phone);
        textDescription.setText(description);
        textTags.setText(tags);

        Button btnViewMap = findViewById(R.id.btn_view_map);
        Button btnGetDirections = findViewById(R.id.btn_get_directions);

        btnViewMap.setOnClickListener(v -> {
            Uri locationUri = Uri.parse("geo:" + latitude + "," + longitude + "?q=" + latitude + "," + longitude);
            Intent intent = new Intent(Intent.ACTION_VIEW, locationUri);
            intent.setPackage("com.google.android.apps.maps");
            startActivity(intent);
        });

        btnGetDirections.setOnClickListener(v -> {
            Uri directionsUri = Uri.parse("google.navigation:q=" + latitude + "," + longitude);
            Intent intent = new Intent(Intent.ACTION_VIEW, directionsUri);
            intent.setPackage("com.google.android.apps.maps");
            startActivity(intent);
        });
    }

}
