package com.example.restaurantguideapp.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.restaurantguideapp.R;
import com.example.restaurantguideapp.activities.RestaurantDetailActivity;
import com.example.restaurantguideapp.models.Restaurant;

import java.util.List;

public class RestaurantAdapter extends RecyclerView.Adapter<RestaurantAdapter.RestaurantViewHolder> {

    private final List<Restaurant> restaurantList;
    private final Context context; // Context for navigating to detail activity

    // Constructor
    public RestaurantAdapter(Context context, List<Restaurant> restaurantList) {
        this.context = context;
        this.restaurantList = restaurantList;
    }

    @NonNull
    @Override
    public RestaurantViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_restaurant, parent, false);
        return new RestaurantViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RestaurantViewHolder holder, int position) {
        Restaurant restaurant = restaurantList.get(position);

        // Set data to views
        holder.textName.setText(restaurant.getName());
        holder.textAddress.setText(restaurant.getAddress());
        holder.textTags.setText(restaurant.getTags());

        // Set OnClickListener for each item
        holder.itemView.setOnClickListener(v -> {
            // Navigate to RestaurantDetailActivity with restaurant details
            Intent intent = new Intent(context, RestaurantDetailActivity.class);
            intent.putExtra("name", restaurant.getName());
            intent.putExtra("address", restaurant.getAddress());
            intent.putExtra("phone", restaurant.getPhone());
            intent.putExtra("description", restaurant.getDescription());
            intent.putExtra("tags", restaurant.getTags());
            intent.putExtra("latitude", restaurant.getLatitude());
            intent.putExtra("longitude", restaurant.getLongitude());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return restaurantList.size();
    }

    static class RestaurantViewHolder extends RecyclerView.ViewHolder {
        TextView textName, textAddress, textTags;

        public RestaurantViewHolder(@NonNull View itemView) {
            super(itemView);
            textName = itemView.findViewById(R.id.text_name);
            textAddress = itemView.findViewById(R.id.text_address);
            textTags = itemView.findViewById(R.id.text_tags);
        }
    }
}
