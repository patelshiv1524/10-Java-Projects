package com.example.restaurantguideapp.activities;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.restaurantguideapp.R;
import com.example.restaurantguideapp.adapters.RestaurantAdapter;
import com.example.restaurantguideapp.models.Restaurant;
import com.example.restaurantguideapp.utils.AppDatabase;
import java.util.List;

public class RestaurantListActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RestaurantAdapter adapter;
    private AppDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant_list);

        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        database = AppDatabase.getInstance(this);

        loadRestaurants();
    }

    private void loadRestaurants() {
        new Thread(() -> {
            // Fetch the list of restaurants from the database
            List<Restaurant> restaurants = database.restaurantDao().getAllRestaurants();

            runOnUiThread(() -> {
                if (restaurants.isEmpty()) {
                    Toast.makeText(this, "No restaurants found!", Toast.LENGTH_SHORT).show();
                } else {
                    // Initialize the adapter with both context and restaurant list
                    adapter = new RestaurantAdapter(this, restaurants);
                    recyclerView.setAdapter(adapter);
                }
            });
        }).start();
    }
}
